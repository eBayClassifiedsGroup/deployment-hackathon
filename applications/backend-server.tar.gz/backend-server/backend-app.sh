#!/bin/bash

##
#		rc.d-Script for a Backend Service Profile
##

#
# Copyright (c) 2004-2008 Peter Rossbach
#
# Authors: Peter Rossbach <pr@objektpark.de>
#
# /etc/init.d/service
#
### BEGIN INIT INFO
# Provides:									mobile-modelpress-webapp44-1_3600
# Required-Start:							$local_fs $remote_fs $network
# X-UnitedLinux-Should-Start:		        $named $time
# Required-Stop:							$local_fs $remote_fs $network
# X-UnitedLinux-Should-Stop:
# Default-Start:								3 5
# Default-Stop:								0 1 2 6
# Short-Description:						backend service mobile-modelpress-webapp44-1_3600
# Description:								Starts/Stops the backend service
### END INIT INFO

test -s /etc/rc.status && . /etc/rc.status

is_running() {
    [ -r "$PID_FILE" ] && pid=`cat $PID_FILE`
    [ -n "$pid" -a -r "/proc/$pid" ] && return 0 || return 1
}

RC_INST=`which chkconfig`
MODUS=0
if [ "$RC_INST" = "" ]; then
	MODUS=1
	RC_INST=`which update-rc.d`
fi

if [ "$RC_INST" = "" ]; then
	echo "No install script for services found."
	exit 1
fi

case "$1" in
	start)
		# Start mobile-modelpress-webapp44-1_3600
		/opt/backend-server/mobile-modelpress-webapp44-1_3600/bin/wrapper start
		exit 0
    ;;

	stop)
		# Stop mobile-modelpress-webapp44-1_3600
        PID_FILE=/var/run/backend-server/mobile-modelpress-webapp44-1_3600/wrapper.pid
        if is_running ; then : ; else
            echo "Server not running"
            exit 0
        fi
		/opt/backend-server/mobile-modelpress-webapp44-1_3600/bin/wrapper stop
        if [ -r "$PID_FILE" ] ; then
            rm $PID_FILE
	    fi
	    exit 0
	;;

	restart)
		#Restarts the mobile-modelpress-webapp44-1_3600
		$0 stop
		$0 start
		exit 0
	;;

	install)
		#installs this script as init-script
		cp /opt/backend-server/mobile-modelpress-webapp44-1_3600/bin/service /etc/init.d/mobile-modelpress-webapp44-1_3600
		if [ $MODUS = 0 ]; then
			$RC_INST --add mobile-modelpress-webapp44-1_3600
		else
			$RC_INST mobile-modelpress-webapp44-1_3600 defaults
		fi
		exit 0
	;;

	uninstall)
		#delete the init-script
		$0 stop
		if [ $MODUS = 0 ]; then
			$RC_INST --del mobile-modelpress-webapp44-1_3600
		else
			$RC_INST -f mobile-modelpress-webapp44-1_3600 remove
		fi
		rm -f /etc/init.d/mobile-modelpress-webapp44-1_3600
		exit 0
	;;

	update)
		#updates the init-script
		$0 stop
		$0 uninstall
		$0 install
		exit 0
	;;

    status)
        PID_FILE=/var/run/backend-server/mobile-modelpress-webapp44-1_3600/wrapper.pid
        if is_running ; then
            echo "Java Service Wrapper mobile-modelpress-webapp44-1_3600 at /opt/backend-server/mobile-modelpress-webapp44-1_3600 (pid ${pid}) is running"
            exit 0
        else
            echo "Java Service Wrapper mobile-modelpress-webapp44-1_3600 at /opt/backend-server/mobile-modelpress-webapp44-1_3600 is stopped"
            exit 1
        fi
    ;;

    statusjvm)
        PID_FILE=/var/run/backend-server/mobile-modelpress-webapp44-1_3600/backend.pid
        if is_running ; then
            echo "Backend mobile-modelpress-webapp44-1_3600 at /opt/backend-server/mobile-modelpress-webapp44-1_3600 (pid ${pid}) is running"
            exit 0
        else
            echo "Backend mobile-modelpress-webapp44-1_3600 at /opt/backend-server/mobile-modelpress-webapp44-1_3600 is stopped"
            exit 1
        fi
    ;;

    infojvm)
        PID_FILE=/var/run/backend-server/mobile-modelpress-webapp44-1_3600/backend.pid
        if is_running ; then
            echo "Backend mobile-modelpress-webapp44-1_3600 at /opt/backend-server/mobile-modelpress-webapp44-1_3600 (pid ${pid}) is running"
            echo "==== Info       ===="
            /opt/backend-server/mobile-modelpress-webapp44-1_3600/bin/tool /opt/backend-server/mobile-modelpress-webapp44-1_3600/bin/info.groovy
            echo "==== Runtime    ===="
            /opt/backend-server/mobile-modelpress-webapp44-1_3600/bin/tool /opt/backend-server/mobile-modelpress-webapp44-1_3600/bin/runtime.groovy
            exit 0
        else
            echo "Backend mobile-modelpress-webapp44-1_3600 at /opt/backend-server/mobile-modelpress-webapp44-1_3600 is stopped"
            exit 1
        fi
    ;;

	*)
		cat >&2 <<-EOF
			Usage: $0 <command>

			where <command> is one of:
				start			- starts The mobile-modelpress-webapp44-1_3600
				stop			- stops the mobile-modelpress-webapp44-1_3600
				restart			- restarts the mobile-modelpress-webapp44-1_3600
				status			- prints the current status of the wrapper of mobile-modelpress-webapp44-1_3600
				statusjvm		- prints the current status of the mobile-modelpress-webapp44-1_3600
				infojvm			- prints the current info of the mobile-modelpress-webapp44-1_3600
				install			- installs this script as mobile-modelpress-webapp44-1_3600 Init-Script
				uninstall		- uninstall the mobile-modelpress-webapp44-1_3600 Init-Script
				update			- update the mobile-modelpress-webapp44-1_3600 Init-Script
				help			- prints this screen
		EOF
		exit 0
	;;
esac
